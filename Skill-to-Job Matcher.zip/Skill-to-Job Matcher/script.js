const jobRoles = {
  "Frontend Developer": ["HTML", "CSS", "JavaScript", "React"],
  "Backend Developer": ["Node.js", "Express", "MongoDB", "API"],
  "Full Stack Developer": ["HTML", "CSS", "JavaScript", "Node.js", "Express", "MongoDB"],
  "Data Analyst": ["Python", "Pandas", "NumPy", "SQL", "Excel"],
  "UI/UX Designer": ["Figma", "Adobe XD", "User Research", "Prototyping"],
  "DevOps Engineer": ["Linux", "Docker", "CI/CD", "AWS"],
};

function matchJobs() {
  const input = document.getElementById("skillInput").value;
  const userSkills = input.split(",").map(skill => skill.trim().toLowerCase());
  const resultsDiv = document.getElementById("results");
  resultsDiv.innerHTML = "";

  Object.entries(jobRoles).forEach(([role, requiredSkills]) => {
    const matched = requiredSkills.filter(skill =>
      userSkills.includes(skill.toLowerCase())
    );

    const missing = requiredSkills.filter(skill =>
      !userSkills.includes(skill.toLowerCase())
    );

    let matchClass = "partial";
    let titleText = "⚠️ Partially Matches";

    if (missing.length === 0) {
      matchClass = "match";
      titleText = "✅ Fully Matches";
    } else if (matched.length === 0) {
      matchClass = "missing";
      titleText = "❌ Not Suitable Yet";
    }

    resultsDiv.innerHTML += `
      <div class="job">
        <h3>${role}</h3>
        <p class="${matchClass}">${titleText}</p>
        <p><strong>Matched Skills:</strong> ${matched.join(", ") || "None"}</p>
        <p><strong>Missing Skills:</strong> <span class="missing">${missing.join(", ") || "None"}</span></p>
      </div>
    `;
  });
}
